<template>
  <div>
    <h1>AI Summary</h1>
    
    <div v-for="(summary, index) in summaries" :key="index" class="summary">
      <SummaryDisplay :text="summary" />
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, computed, watchEffect } from 'vue'
import { useSummaryStore } from '@/stores/summaryStore'
import SummaryDisplay from '@/components/Dashboard/SummaryDisplay.vue';


export default defineComponent({
  name: 'AISummaryView',
  components: {
    SummaryDisplay,
  },
  setup() {
    const summaryStore = useSummaryStore();
    const summaries = summaryStore.summaries;

    return {
      summaries,
    };
  },
});
</script>

<style scoped>
.error {
  color: red;
  margin-top: 1rem;
}

.summary {
  margin-top: 1rem;
  font-weight: bold;
}
</style>
