<template>
  <div class="login-container">
    <h2>Login</h2>
    <form @submit.prevent="submitLogin">
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" id="username" v-model="username" required />
      </div>

      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" id="password" v-model="password" required />
      </div>

      <button type="submit">Login</button>
    </form>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue';
import { useAuthStore } from '@/stores/userAuthentication';
import { useRouter  } from 'vue-router';


export default defineComponent({
  data() {
    return {
      username: '',
      password: '',
    }
  },
  setup() {
    const router = useRouter(); // Initialize the router
    const authStore = useAuthStore(); // Access Pinia store

    return { router, authStore };
  },
  methods: {
    async submitLogin() {
      // Destructure router and authStore from this
      const { router, authStore } = this;

      // Give typeScript types for variables
      const userData: {username: string; password: string} = {
        username: this.username,
        password: this.password,
      }
  
      

      // Check if there is any input in username and password, and login
      try {
        if (userData.username && userData.password) {
        console.log('login successful');
        authStore.logIn();
        console.log('isuserLoggedin? ', authStore.isLoggedIn)

        // TODO: Navigate to home
        router.push('/');
          
      } else {
        console.log('Username or password is empty');
      }
      console.log('Login data:', userData)
      } catch (error) {
        console.log('There was an error: ', error);
      }

    },
  },
})
</script>

<style scoped>
.login-container {
  max-width: 400px;
  margin: 1em auto;
  padding: 2rem;
  border: 1px solid #ccc;
  border-radius: 8px;
}

.form-group {
  margin-bottom: 1rem;
}

label {
  display: block;
  margin-bottom: 0.5rem;
}

input {
  width: 100%;
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  padding: 0.5rem 1rem;
  background-color: #4262b9;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
</style>
