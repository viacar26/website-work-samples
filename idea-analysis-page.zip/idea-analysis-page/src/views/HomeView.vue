<template>
  <div class="home">
    <div id="body" class="body">
      <HomeBody></HomeBody>
      <h3>Select Questions to Include: </h3>
      <IncludeQuestions></IncludeQuestions>
      <h3>Select AI Prompt: </h3>
      <AiPrompt></AiPrompt>
      <PdfUploader></PdfUploader>
    </div>
  </div>
</template>

<script setup lang="ts">

import HomeBody from '@/components/Dashboard/HomeBody.vue';
import PdfUploader from '@/components/Dashboard/PdfUploader.vue';
import IncludeQuestions from '@/components/Dashboard/IncludeQuestions.vue';
import AiPrompt from '@/components/Dashboard/AiPrompt.vue';


</script>

  <style lang="scss">
  body {
    background-color: #FFFFFF;
    margin: 0px;
    font-family: Arial, Helvetica, sans-serif;
    color: #1E252B;
  }

  .button {
    margin: 30px;
    background-color: #0F2439;
    border-radius: 5px;
    font-size: 18px;
    width: 260px;
    height: 60px;
    color: #FFFFFF;
    padding: 20px;
    box-shadow: inset 0 -0.6em 1em -0.35em rgba(0, 0, 0, 0.17),
      inset 0 0.6em 2em -0.3em rgba(255, 255, 255, 0.15),
      inset 0 0 0em 0.05em rgba(255, 255, 255, 0.12);
    text-align: center;
    cursor: pointer;
  }

  .summarize-button {
    display: flex;
    justify-content: flex-start;
    padding-left: 400px;
  }

  h1 {
    font-size: 30px;
    margin-bottom: 20px;
  }

  h2 {
    font-size: 25px;
  }

  h3 {
    font-size: 20px;
  }

  input {
    width: 100%;
    height: 40px;
    margin-bottom: 20px;
  }

  label {
    font-size: 20px;
    margin-bottom: 5px;
  }

  li {
    font-size: 18px;
  }

  .container {
    display: flex;
    justify-content: space-between; /* or flex-start for left alignment */
    align-items: flex-start; /* Align items to the top */
  }

  .body {
    flex: 1; /* Allow the body to take up the remaining space */
    color: #1E252B;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
  }

  .out-of-stock-img {
    opacity:0.5
  }

  p {
    font-size: 22px;
  }

  select {
    height: 40px;
    font-size: 20px;
    background-color: white;
    cursor: pointer;
  }

  textarea {
    width: 95%;
    height: 70px;
    padding: 10px;
    font-size: 20px;
    margin-bottom: 20px;
  }

  ul {
    list-style-type: none;
  }

  @media only screen and (max-width: 600px) {
    .container {
      flex-direction: column;
    }

    .menu-display,
    .body {
      margin-left: 10px;
      width: 100%;
    }

    .review-form {
      width: 90%;
    }
}
</style>
