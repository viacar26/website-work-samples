<template>
  <div class="nav-bar">
        <h1>IDEAI Analytics</h1>
    </div>
</template>

<script setup lang="ts">

</script>

<style lang="scss">
  .nav-bar {
    background: linear-gradient(-90deg, #0F2439, #4494DA);
    height: 120px;
    margin-bottom: 25px;
    -webkit-box-shadow: 0px 2px 15px -12px rgba(0, 0, 0, 0.57);
    -moz-box-shadow: 0px 2px 15px -12px rgba(0, 0, 0, 0.57);
    box-shadow: 1px 1px 5px rgba(0, 0, 0, 0.57);
    color: #FFFFFF;
    display: flex;
    align-items: end;
    padding-left: 50px;
    padding-bottom: 5px;
  }

</style>
