<template>
  <div class="container">
    <div class="menu-display">
      <h3>Home</h3>
      <h3>Login</h3>
      <h3>AI Summary</h3>
    </div>

    <div id="body" class="body">
      <h1>Home</h1><br>
      <p>To begin summarizing your IDEA surveys, start by uploading the surveys you want summarized. 
        Then, select which qualitiative questions you want analyzed, which AI prompt you'd like to use, and click “Summarize” to create a custom AI-generated report.
        </p>
    </div>
  </div>
</template>

<script setup lang="ts">

</script>

<style lang="scss">
  .menu-display {
    flex: 0 0 200px; /* Ensure the menu has a fixed width */
    border: 2px solid #d8d8d8;
    width: 200px;
    margin: 20px;
    padding: 15px;
    -webkit-box-shadow: 0px 2px 15px -12px rgba(0, 0, 0, 0.57);
    -moz-box-shadow: 0px 2px 15px -12px rgba(0, 0, 0, 0.57);
    box-shadow: 2px 15px -12px rgba(0, 0, 0, 0.57);
  }

  .body {
    flex: 1; /* Allow the body to take up the remaining space */
    color: #1E252B;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
  }

</style>
