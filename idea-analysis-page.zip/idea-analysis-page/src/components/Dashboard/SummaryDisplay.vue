<template>
    <div v-if="visible" class="compContainer">
        <button class="download-button" @click="download">Save as PDF</button>
        <br>
        <br>
        <button class="delete-button" @click="disappear" > Delete Summary </button>
        <br>
        <div class="summary-text">
          <h2>Chat GPT</h2>
          <div v-html="htmlFriendlySummaryText"></div>
        </div>

    </div>
  
</template>
  
<script setup lang="ts">


  import axios from 'axios';
  import { ref } from 'vue';
  import { useSummaryStore } from '@/stores/summaryStore'

  
  const props = defineProps({
    text: {
     type: String,
     required: true,
   },
  });

  const summary = props.text;
  const htmlFriendlySummaryText = summary.replace(/\n/g, " <br> ").replace(/:/g, ": <br> ");
  const visible = ref(true);
  const summaryStore = useSummaryStore();

  const disappear = () => {
    summaryStore.deleteSummary(summary);
    visible.value = false;
  }

  async function download() {
  const formData = new FormData();
  formData.append('summary', summary);

  try {
    const response = await axios.post('http://localhost:8000/getSummaryPDF/', formData, {
      responseType: 'blob',
    });

    const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'Course_Feedback_Summary.pdf');
    document.body.appendChild(link);
    link.click();

    link.remove();
    window.URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Failed to download PDF:', error);
    alert('An error occurred while downloading the PDF.');
  }
}

  
  
</script>
  
  <style lang="scss">


  .compContainer{
    width: 500px;
    float: center;
    margin-left: 25%;
    margin-right: 20px;
    margin-bottom: 20px;
  }

  .download-button{
    float: right;
    color: white;
    background-color: #252F40;
    border-radius: 5px;
    border-style: none;
    height: 25px; 
  }

  .delete-button{
    float: right;
    color: white;
    background-color: #A6260D;
    border-radius: 5px;
    border-style: none;
    height: 25px;
  }

  .summary-text{
    text-align: left;
    margin-top: 10px;
    border-style: solid;
    border-color: #1E252B;
    background-color: #DEE2E6;
    border-radius: 10px;  
    padding: 10px;
    padding-top: 0px;
  }
  </style>
  