<template>
  <div class="container">
    <div class="selection">
      <div
          v-for="(option, index) in options"
          :key="index"
          class="checkbox-option">
          <input
          type="checkbox"
          :value="option.value"
          v-model="selectedValues"
          @change="onChange"
          />
          <label>{{ option.label }}</label>
        </div>
    </div>
  </div>  
</template>

<script lang="ts">
export default {
  name: 'CheckBox',
  props: {
    options: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      selectedValues: [] as string[],
    };
  },
  methods: {
    onChange(event) {
      this.$emit('change', this.selectedValues);
    },
  },
};
</script>

<style scoped>

.container {
  display: flex;
  justify-content: center; 
  align-items: center; 
}

.selection {
  padding: 0.5rem;
  border-radius: 4px;
  border: 1px solid #ccc;
  width: 50%;
  align-items: center;
}


.checkbox-option {
  display: flex;
  align-items: center;
  margin: 0.1rem 0;
  cursor: pointer
}


.checkbox-option input[type="checkbox"] {
  appearance: none;
  width: 20px;
  height: 20px;
  border: 2px solid #ccc;
  border-radius: 4px;
  cursor: pointer;
  transition: 0.2s;
}

.checkbox-option input[type="checkbox"]:checked {
  background-color: #4494DA;
  border-color: #4494DA;
}

.checkbox-option input[type="checkbox"]:checked::before {
  content: "✓";
  color: white;
  display: block;
  text-align: center;
  font-size: 14px;
}
</style>
