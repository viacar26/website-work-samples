<template>
  <div>
    <select v-model="selectedPrompt" @change="handlePromptChange">
      <option value="">Select a prompt</option>
      <option
        v-for="(option, index) in promptOptions"
        :key="index"
        :value="option.value"
      >
        {{ option.label }}
      </option>
    </select>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { usePromptStore } from '@/stores/promptStore'

const promptStore = usePromptStore()
const selectedPrompt = ref('')

const promptOptions = [
  { value: 'Summarize the top 3 student responses', label: 'Summarize the top 3 student responses' },
  {
    value: 'Pull out three direct quotes that capture the sentiment and thoughts of respondents',
    label: 'Pull out three direct quotes that capture the sentiment and thoughts of respondents',
  },
  {
    value: 'Give the top three things students suggest to improve the course',
    label: 'Give the top three things students suggest to improve the course',
  },
]

const handlePromptChange = () => {
  promptStore.setPrompt(selectedPrompt.value)
}
</script>

<style scoped>
select {
  padding: 0.5rem;
  border-radius: 4px;
  border: 1px solid #ccc;
  width: 300px;
}
</style>
