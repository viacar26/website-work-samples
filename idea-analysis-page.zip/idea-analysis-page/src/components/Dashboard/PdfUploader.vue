<template>
  <h3>Select IDEA Survey(s)</h3>
  <WarningMsg></WarningMsg>
  <div class="pdf-upload">
    <!-- Drag-and-drop or click container -->
    <div 
      class="upload-container" 
      @drop.prevent="handleDrop" 
      @dragover.prevent 
      @click="triggerFileInput"
    >
      <p>Drag and drop PDF files</p>
      <img class= "doc-image" src="../../assets/images/document icon.png" alt="Black icon of a document">
      <p>or click to select files.</p>
    </div>

    <!-- Hidden file input -->
    <input
      ref="fileInput"
      type="file"
      multiple
      @change="handleFileChange"
      accept="application/pdf"
      class="hidden-file-input"
    />

    <!-- Uploaded files list -->
    <div>
      <ul>
        <li
          v-for="(file, index) in uploadedFiles"
          :key="index"
          class="uploaded-files"
        >
          {{ file.name }}
        </li>
      </ul>
    </div>
  </div>

  <FormButton class="summary-button"></FormButton>
</template>

<script setup lang="ts">
import { useUploadStore } from '@/stores/uploadStore';
import { storeToRefs } from 'pinia';
import FormButton from './FormButton.vue';
import WarningMsg from '@/components/Dashboard/WarningMsg.vue';
import { ref } from 'vue';

const store = useUploadStore()
const { uploadedFiles } = storeToRefs(store)
const fileInput = ref<HTMLInputElement | null>(null);

//Add Files
function handleFileChange(event: Event) {
  const files = (event.target as HTMLInputElement).files
  if (files) {
    Array.from(files).forEach(file => {
      store.addFile(file) // Add each file to the store
    })
  }
}

// Trigger file input
function triggerFileInput() {
  fileInput.value?.click();
}

// Handle drag-and-drop files
function handleDrop(event: DragEvent) {
  const files = event.dataTransfer?.files;
  if (files) {
    Array.from(files).forEach(file => {
      store.addFile(file); // Add each file to the store
    });
  }
}

</script>

<style scoped lang="scss">
.pdf-upload {
  display: flex;
  padding-left: 20%;
  padding-right: 20%;
  margin: 10px;
  justify-content: center;
}

.upload-container {
  border: 4px solid #1E252B;
  border-radius: 10px;
  padding: 20px;
  text-align: center;
  cursor: pointer;
  background-color: #f9f9f9;
  transition: background-color 0.3s, border-color 0.3s;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;

  &:hover {
    background-color: #f1f1f1;
    border-color: #aaa;
  }
}

.doc-image {
  width: 150px;
  height: auto;
  margin: 5px 0;

}

.hidden-file-input {
  display: none;
}

.uploaded-files {
  font-size: 14px;
}

.summary-button {
  margin: 30px;
  display: flex;
  justify-content: center;
  background-color: #ffffff;
}
</style>
