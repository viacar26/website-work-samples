<template>
  <div class="summarize-button">
    <button class="button" @click="sendPost" :disabled="!isFormValid">
      {{ isFormValid ? 'Summarize' : 'Please complete all fields' }}
    </button>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import axios from 'axios'
import { useUploadStore } from '@/stores/uploadStore'
import { useSummaryStore } from '@/stores/summaryStore'
import { useQuestionStore } from '@/stores/questionStore'
import { usePromptStore } from '@/stores/promptStore'
import router from '@/router'

const uploadStore = useUploadStore()
const summaryStore = useSummaryStore()
const questionStore = useQuestionStore()
const promptStore = usePromptStore()


const isFormValid = computed(() => {
  return (
    uploadStore.uploadedFiles.length > 0 &&
    Object.values(questionStore.selectedQuestions).some(v => v) &&
    promptStore.selectedPrompt.length > 0
  )
})

const sendPost = async () => {
  try {
    if (!isFormValid.value) {
      alert('Please fill in all required fields')
      return
    }

    const formData = new FormData()

    // Add selected questions
    formData.append(
      'comments',
      questionStore.selectedQuestions.comments.toString(),
    )
    formData.append('good', questionStore.selectedQuestions.good.toString())
    formData.append('bad', questionStore.selectedQuestions.bad.toString())

    // Get prompt from store
    const prompt = promptStore.selectedPrompt
    formData.append('prompt', prompt)
    console.log(prompt)
    // Debug log
    console.log('Sending prompt:', prompt)

    // Add files
    uploadStore.uploadedFiles.forEach(file => {
      formData.append('files', file)
    })

    const response = await axios.post(
      'http://localhost:8000/upload/',
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      },
    )

    if (response.data.summary) {
      summaryStore.addSummary(response.data.summary)
      router.push('/summary')
      uploadStore.clearFiles()
    } else {
      throw new Error('No summary received')
    }
  } catch (error) {
    console.error('Error:', error)
    alert('An error occurred while processing your request')
  }
}
</script>
