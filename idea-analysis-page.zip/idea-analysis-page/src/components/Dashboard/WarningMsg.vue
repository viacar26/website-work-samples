<template>
    <div id="pdf-warning" class="warning">
      <p>All surveys must be attached as a PDF. Attached PDFs that are not IDEA surveys may result in the
        AI not functioning properly or in an inaccurate summary being generated. 
        </p>
      </div>
  </template>
  
  <script setup lang="ts">
  
  </script>
  
  <style scoped lang="scss">
    .warning {
      display: flex;
      align-items: center;
      justify-content: center;
      border: 2px solid #AE6002;
      color: #ffff;
      background-color: #AE6002;
      width: 75%;
      margin: 20px auto;
      padding: 15px;
      border-radius: 10px;
      -webkit-box-shadow: 0px 2px 15px -12px rgba(0, 0, 0, 0.57);
      -moz-box-shadow: 0px 2px 15px -12px rgba(0, 0, 0, 0.57);
      box-shadow: 2px 15px -12px rgba(0, 0, 0, 0.57);
    }
    
  </style>
  