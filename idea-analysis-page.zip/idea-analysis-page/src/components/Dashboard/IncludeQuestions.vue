<template>
  <div class="question-selector">
    <div class="checkbox-group">
      <label>
        <input
          type="checkbox"
          v-model="selectedQuestions.comments"
          @change="updateSelections"
        />
        Comments
      </label>
      <label>
        <input
          type="checkbox"
          v-model="selectedQuestions.good"
          @change="updateSelections"
        />
        What was good
      </label>
      <label>
        <input
          type="checkbox"
          v-model="selectedQuestions.bad"
          @change="updateSelections"
        />
        What could be improved
      </label>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useQuestionStore } from '@/stores/questionStore'

const questionStore = useQuestionStore()

const selectedQuestions = ref({
  comments: false,
  good: false,
  bad: false,
})

const updateSelections = () => {
  questionStore.updateSelections(selectedQuestions.value)
}
</script>

<style scoped lang="scss">
.question-selector {
  margin: 20px 0;
  display: flex;
  justify-content: center;
}

.checkbox-group {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 1rem;

  label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 18px;
    cursor: pointer;

    input[type='checkbox'] {
      margin: 0;
      width: 16px;
      height: 16px;
    }

    span {
      margin-left: 0.5rem;
    }
  }
}
</style>
