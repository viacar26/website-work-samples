<template>
  <div>
    <select @change="onChange($event)">
      <option
        v-for="(option, index) in options"
        :key="index"
        :value="option.value"
      >
        {{ option.label }}
      </option>
    </select>
  </div>
</template>

<script lang="ts">
export default {
  name: 'DropdownMenu',
  props: {
    options: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      selectedValue: String,
    };
  },
  methods: {
    onChange(event: Event) {
      const target = event.target as HTMLSelectElement;
      this.$emit('change', target.value)
    },
  },
}
</script>

<style scoped>
select {
  padding: 0.5rem;
  border-radius: 4px;
  border: 1px solid #ccc;
}
</style>
