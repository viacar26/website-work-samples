<template>
  <div class="app">
    <NavBar></NavBar>
    <div class="container">
      <div class="nav-display">
        <nav class="nav">
        <RouterLink to="/" class="nav-link">Home</RouterLink>
        <RouterLink to="/login" class="nav-link">Login</RouterLink>
        <RouterLink to="/summary" class="nav-link">AI Summary</RouterLink>
        </nav>
      </div>

      <div id="body" class="body">
        <RouterView />
      </div>
    </div>
    
  </div>
</template>

<script setup lang="ts">
import NavBar from './components/SharedComponents/NavBar.vue';
</script>

<style>
.app {
  text-align: center;
}
.nav-display {
    flex: 0 0 200px; /* Ensure the menu has a fixed width */
    border: 2px solid #d8d8d8;
    width: 200px;
    margin: 20px;
    padding: 15px;
    -webkit-box-shadow: 0px 2px 15px -12px rgba(0, 0, 0, 0.57);
    -moz-box-shadow: 0px 2px 15px -12px rgba(0, 0, 0, 0.57);
    box-shadow: 2px 15px -12px rgba(0, 0, 0, 0.57);
  }

  .nav {
    font-family: Arial, Helvetica, sans-serif;
  }
  
  .nav-link {
    display: block;
    margin-bottom: 8px; 
  }

  .body {
    flex: 1; /* Allow the body to take up the remaining space */
    color: #1E252B;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
  }
</style>
