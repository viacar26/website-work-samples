import { defineStore } from 'pinia'

interface QuestionSelections {
  comments: boolean
  good: boolean
  bad: boolean
}

export const useQuestionStore = defineStore('question', {
  state: () => ({
    selectedQuestions: {
      comments: false,
      good: false,
      bad: false,
    } as QuestionSelections,
  }),
  actions: {
    updateSelections(selections: QuestionSelections) {
      this.selectedQuestions = selections
    },
  },
})
