import { defineStore } from 'pinia'

export const useUploadStore = defineStore('uploadStore', {
    state: () => ({
      uploadedFiles: [] as File[], 
      index: 0
    }),
    
    actions: {
      addFile(file: File) {
        this.uploadedFiles.push(file); // Add the file to the state
        this.index++ // Increment index
      },
      removeFile(index: number) {
        this.uploadedFiles.splice(index, 1); // Remove the file by index
      },
      clearFiles() {
        this.uploadedFiles = []; // Clear all files
      }
    }
  });