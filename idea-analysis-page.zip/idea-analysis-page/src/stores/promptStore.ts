import { defineStore } from 'pinia'

interface PromptState {
  selectedPrompt: string
}

export const usePromptStore = defineStore('prompt', {
  state: (): PromptState => ({
    selectedPrompt: '',
  }),

  actions: {
    setPrompt(prompt: string) {
      this.selectedPrompt = prompt
    },
  },

  getters: {
    getPrompt: state => state.selectedPrompt,
  },
})
