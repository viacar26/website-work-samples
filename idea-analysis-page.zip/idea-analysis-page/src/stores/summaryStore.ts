import { defineStore } from 'pinia'

export const useSummaryStore = defineStore('summaryStore', {
  state: () => ({
    summaries: [] as string[],
  }),
  
  actions: {
    addSummary(summary: string) {
      this.summaries.push(summary);
      this.summaries = [...this.summaries];
    },
    deleteSummary(summary: string) {
      this.summaries = this.summaries.filter(item => item !== summary);
      console.log(this.summaries);
    },
  },
})
