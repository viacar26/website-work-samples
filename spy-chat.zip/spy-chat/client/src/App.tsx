import { useEffect, useState } from 'react';
import { socket } from './socket';
import './App.css';
import CryptoJS from 'crypto-js';


function App() {
  const [isConnected, setIsConnected] = useState(socket.connected);
  const [input, setInput] = useState('');
  const [password, setPassword] = useState('');
  const [messages, setMessages] = useState<string[]>([]);

  function requestPassword(message: string) {
    const password = window.prompt("Enter your password:");
    if (password) {
      const bytes = CryptoJS.AES.decrypt(message, password);
      console.log("Decryption bytes:", bytes);
      
      const decryptedMessage = bytes.toString(CryptoJS.enc.Utf8);
      
      if (!decryptedMessage) {
        console.error("Decryption failed. Possibly wrong password or invalid ciphertext.");
      } else {
        console.log("Decrypted message:", decryptedMessage);
        setMessages((prevMessages) => 
          prevMessages.map((msg) => (msg === message ? decryptedMessage : msg))
        );
      }
    } else {
      console.log("No password entered");
    }
  }  

  //encrypt message
  function encryptMessage(encryptedMessage: string, password: string){
    const encrypted = CryptoJS.AES.encrypt(encryptedMessage, password).toString();
    socket.emit('message', encrypted);
  }

  //decrypt message
  function decryptMessage(arr: string[], target: string, replacement: string): string[] {
  let replaced = false;
  return arr.map((word) => {
    if (word === target && !replaced) {
      replaced = true;
      return replacement;
    }
    return word;
  });
}
  

  useEffect(() => {

    socket.connect();
    
    function onConnect() {
      setIsConnected(true);
    }

    function onDisconnect() {
      setIsConnected(false);
    }

    function onMessage(encryptedMessage: string) {
      setMessages((messages) => [...messages, encryptedMessage]);
    }


    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    socket.on('message', onMessage);
    socket.on('encryptedMessage', encryptMessage);

    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
      socket.off('encryptedMessage', encryptMessage);
    };
  }, []);

  return (
    <>
      <h1>Spy Chat</h1>
      <hr className="line"></hr>
      <div className="card">
        { messages.map((message, index) => (
          <div>
            <button className="msg-button" key={index} onClick={() => requestPassword(message)}>{message}</button>
          </div>
        ))
        }
        
      </div>
      <form  id="message-form">
        <div>
          <p>Message:</p>
          <input 
            type='text' 
            placeholder='Enter your message' 
            value={input} 
            onChange={(e) => setInput(e.target.value)}
          />
        </div>
        <div>
          <p>Password: </p>
          <input 
            type='text' 
            placeholder='Enter your password'
            value={password}
            onChange={(e) => setPassword(e.target.value)} 
          />
        </div>
          <button onClick={ (e) => {
            e.preventDefault();
            if (input && password) {
              encryptMessage(input, password);
            }
          }}>
            Encrypt
          </button>
      </form>
    </>
  )
}

export default App
